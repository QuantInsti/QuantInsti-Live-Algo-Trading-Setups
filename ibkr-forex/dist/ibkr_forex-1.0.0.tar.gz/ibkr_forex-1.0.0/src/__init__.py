"""

@author: Jose Carlos Gonzales Tanaka
LinkedIn profile: https://www.linkedin.com/in/jose-carlos-gonzales-tanaka/

############################# DISCLAIMER #############################
This file is a template only and should not be
used for live trading without appropriate backtesting and tweaking of
the strategy parameters.
######################################################################

File: The trading app's main file

Copyright 2025 QuantInsti Quantitative Learning Pvt. Ltd. 
Licensed under the QuantInsti Open License (QOL) v1.1 (the "License"). 
You may not use this file except in compliance with the License. 
You may obtain a copy of the License in LICENSE.md at the repository root or at https://www.quantinsti.com. 
Non-Commercial use only; see the License for permitted use, attribution, and restrictions.

"""
